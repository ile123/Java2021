2. vježba
