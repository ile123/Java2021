5. vježba
