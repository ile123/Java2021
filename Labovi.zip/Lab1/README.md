1. vježba
